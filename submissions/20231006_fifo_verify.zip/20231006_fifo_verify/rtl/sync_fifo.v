// 
// sync_fifo.v  –  Synchronous FIFO core
// 
// Parameters
//   DATA_WIDTH : width of each data word  (default 8)
//   DEPTH      : number of entries        (default 16)
// Ports
//   clk        : clock (rising-edge active)
//   rst_n      : synchronous, active-low reset
//   wr_en      : write enable
//   wr_data    : write data
//   wr_full    : asserted when FIFO is full
//   rd_en      : read enable
//   rd_data    : read data (registered output)
//   rd_empty   : asserted when FIFO is empty
//   count      : number of valid entries currently stored
// 

module sync_fifo #(
    parameter integer DATA_WIDTH = 8,
    parameter integer DEPTH      = 16
)(
    input  wire                   clk,
    input  wire                   rst_n,

    // Write interface
    input  wire                   wr_en,
    input  wire [DATA_WIDTH-1:0]  wr_data,
    output wire                   wr_full,

    // Read interface
    input  wire                   rd_en,
    output reg  [DATA_WIDTH-1:0]  rd_data,
    output wire                   rd_empty,

    // Status
    output wire [ADDR_WIDTH:0]    count
);

    // Local parameter: address width = ceil(log2(DEPTH))
    parameter integer ADDR_WIDTH = clog2(DEPTH);

    // Function: ceiling log2
    function integer clog2;
        input integer value;
        integer i;
        begin
            clog2 = 0;
            for (i = value - 1; i > 0; i = i >> 1)
                clog2 = clog2 + 1;
        end
    endfunction

    // Internal storage and pointer registers
    reg [DATA_WIDTH-1:0] mem [0:DEPTH-1];

    reg [ADDR_WIDTH-1:0] wr_ptr;   // write pointer (index into mem)
    reg [ADDR_WIDTH-1:0] rd_ptr;   // read  pointer (index into mem)
    reg [ADDR_WIDTH:0]   count_r;  // occupancy counter (needs one extra bit)

    // Output assignments
    assign wr_full  = (count_r == DEPTH);
    assign rd_empty = (count_r == 0);
    assign count    = count_r;

    // Valid operation qualifiers
    wire do_write = wr_en & ~wr_full;
    wire do_read  = rd_en & ~rd_empty;

    integer k;

    always @(posedge clk) begin
        if (~rst_n) begin
            // Synchronous reset
            wr_ptr  <= {ADDR_WIDTH{1'b0}};
            rd_ptr  <= {ADDR_WIDTH{1'b0}};
            count_r <= {(ADDR_WIDTH+1){1'b0}};
            rd_data <= {DATA_WIDTH{1'b0}};
            for (k = 0; k < DEPTH; k = k + 1)
                mem[k] <= {DATA_WIDTH{1'b0}};
        end else begin

            // Write path
            if (do_write) begin
                mem[wr_ptr] <= wr_data;
                // Wrap write pointer
                if (wr_ptr == DEPTH - 1)
                    wr_ptr <= {ADDR_WIDTH{1'b0}};
                else
                    wr_ptr <= wr_ptr + 1'b1;
            end

            // Read path
            if (do_read) begin
                rd_data <= mem[rd_ptr];
                // Wrap read pointer
                if (rd_ptr == DEPTH - 1)
                    rd_ptr <= {ADDR_WIDTH{1'b0}};
                else
                    rd_ptr <= rd_ptr + 1'b1;
            end

            // Count update
            //   write only  → count++
            //   read  only  → count--
            //   both        → count unchanged
            //   neither     → count unchanged
            if (do_write & ~do_read)
                count_r <= count_r + 1'b1;
            else if (do_read & ~do_write)
                count_r <= count_r - 1'b1;
            // else unchanged

        end
    end

endmodule
