
// tb_sync_fifo.v  –  Self-Checking Testbench for sync_fifo_top

// Contains:
//   • Golden Reference Model (independent, cycle-accurate)
//   • Scoreboard (automatic comparison every rising edge)
//   • 8 Directed Tests
//   • Manual Coverage Counters
//   • Detailed failure reporting with $finish on first mismatch


`timescale 1ns/1ps

module tb_sync_fifo;


// Parameters – must match DUT

parameter integer DATA_WIDTH = 8;
parameter integer DEPTH      = 16;
parameter integer ADDR_WIDTH = 4;   // clog2(16) = 4
parameter integer CLK_PERIOD = 10;  // 10 ns → 100 MHz


// DUT interface signals

reg                   clk;
reg                   rst_n;
reg                   wr_en;
reg  [DATA_WIDTH-1:0] wr_data;
wire                  wr_full;
reg                   rd_en;
wire [DATA_WIDTH-1:0] rd_data;
wire                  rd_empty;
wire [ADDR_WIDTH:0]   count;


// DUT instantiation

sync_fifo_top #(
    .DATA_WIDTH (DATA_WIDTH),
    .DEPTH      (DEPTH)
) dut (
    .clk      (clk),
    .rst_n    (rst_n),
    .wr_en    (wr_en),
    .wr_data  (wr_data),
    .wr_full  (wr_full),
    .rd_en    (rd_en),
    .rd_data  (rd_data),
    .rd_empty (rd_empty),
    .count    (count)
);


// Clock generation

initial clk = 0;
always #(CLK_PERIOD/2) clk = ~clk;


// Golden Reference Model state

reg [DATA_WIDTH-1:0] model_mem     [0:DEPTH-1];
integer              model_wr_ptr;
integer              model_rd_ptr;
integer              model_count;
reg [DATA_WIDTH-1:0] model_rd_data;


// Testbench control variables

integer              cycle;          // cycle counter (reset per test)
integer              global_cycle;   // overall cycle counter
integer              seed;           // random seed
reg [63:0]           test_name [0:3]; // simple label storage not used for compare
reg [8*32-1:0]       current_test;  // current test name string


// Coverage counters

integer cov_full;
integer cov_empty;
integer cov_wrap;
integer cov_simul;
integer cov_overflow;
integer cov_underflow;

// Wrap tracking helpers
reg [ADDR_WIDTH-1:0] prev_wr_ptr;
reg [ADDR_WIDTH-1:0] prev_rd_ptr;


// Golden Model Update (same clock edge as DUT)

always @(posedge clk) begin
    if (~rst_n) begin
        model_wr_ptr  = 0;
        model_rd_ptr  = 0;
        model_count   = 0;
        model_rd_data = 0;
    end else begin
        // Determine valid ops using model's own state
        if (wr_en && (model_count < DEPTH)) begin
            model_mem[model_wr_ptr] = wr_data;
            model_wr_ptr = (model_wr_ptr == DEPTH-1) ? 0 : model_wr_ptr + 1;
            if (!rd_en || (model_count == 0))  // count update handled below
                ;  // placeholder
        end

        if (rd_en && (model_count > 0)) begin
            model_rd_data = model_mem[model_rd_ptr];
            model_rd_ptr = (model_rd_ptr == DEPTH-1) ? 0 : model_rd_ptr + 1;
        end

        // Count update
        if ((wr_en && (model_count < DEPTH)) && !(rd_en && (model_count > 0)))
            model_count = model_count + 1;
        else if (!(wr_en && (model_count < DEPTH)) && (rd_en && (model_count > 0)))
            model_count = model_count - 1;
        // else (both or neither) → unchanged
    end
end


// Scoreboard: compare DUT vs model after every rising edge


task automatic scoreboard_check;
    input integer cyc;
    input [8*32-1:0] tname;
    begin
        // Allow signals to settle
        #1;
        // --- rd_data: only meaningful if a read occurred last cycle ---
        // We compare count, flags every cycle; rd_data when read happened
        if (rd_en && !rd_empty) begin
            if (rd_data !== model_rd_data) begin
                $display("SCOREBOARD MISMATCH — rd_data");
                $display("  Expected : 0x%02h", model_rd_data);
                $display("  Got      : 0x%02h", rd_data);
                $finish;
            end
        end

        // Compare count
        if (count !== model_count) begin
            $display("==============================");
            $display("SCOREBOARD MISMATCH at time %0t ns", $time);
            $display("  Test        : %s", tname);
            $display("  Cycle       : %0d", cyc);
            $display("  Seed        : %0d", seed);
            $display("  Signal      : count");
            $display("  Expected    : %0d", model_count);
            $display("  Got         : %0d", count);
            $display("  wr_en=%b wr_data=0x%02h rd_en=%b", wr_en, wr_data, rd_en);
            $display("  model_wr_ptr=%0d model_rd_ptr=%0d", model_wr_ptr, model_rd_ptr);
            $display("==============================");
            $finish;
        end

        // Compare rd_empty flag
        if (rd_empty !== (model_count == 0)) begin
            $display("==============================");
            $display("SCOREBOARD MISMATCH at time %0t ns", $time);
            $display("  Test        : %s", tname);
            $display("  Cycle       : %0d", cyc);
            $display("  Signal      : rd_empty");
            $display("  Expected    : %b", (model_count == 0));
            $display("  Got         : %b", rd_empty);
            $display("  model_count=%0d", model_count);
            $display("==============================");
            $finish;
        end

        // Compare wr_full flag
        if (wr_full !== (model_count == DEPTH)) begin
            $display("==============================");
            $display("SCOREBOARD MISMATCH at time %0t ns", $time);
            $display("  Test        : %s", tname);
            $display("  Cycle       : %0d", cyc);
            $display("  Signal      : wr_full");
            $display("  Expected    : %b", (model_count == DEPTH));
            $display("  Got         : %b", wr_full);
            $display("  model_count=%0d", model_count);
            $display("==============================");
            $finish;
        end
    end
endtask


// Helper: assert reset for n cycles

task do_reset;
    input integer n;
    integer i;
    begin
        rst_n   = 1'b0;
        wr_en   = 1'b0;
        rd_en   = 1'b0;
        wr_data = {DATA_WIDTH{1'b0}};
        repeat(n) @(posedge clk);
        #1; // settle
        rst_n = 1'b1;
        cycle = 0;
    end
endtask


// Helper: one clock tick + scoreboard

task tick;
    input [8*32-1:0] tname;
    begin
        @(posedge clk);
        cycle        = cycle + 1;
        global_cycle = global_cycle + 1;
        scoreboard_check(cycle, tname);

        // Coverage sampling
        if (model_count == DEPTH)                          cov_full      = cov_full + 1;
        if (model_count == 0)                              cov_empty     = cov_empty + 1;
        if (wr_en && !wr_full && rd_en && !rd_empty)       cov_simul     = cov_simul + 1;
        if (wr_en && wr_full)                              cov_overflow  = cov_overflow + 1;
        if (rd_en && rd_empty)                             cov_underflow = cov_underflow + 1;
        // Wrap: detect when wr_ptr or rd_ptr crossed 0
        if (wr_en && !wr_full &&
            dut.u_fifo.wr_ptr == 0 && model_count > 0)    cov_wrap      = cov_wrap + 1;
        if (rd_en && !rd_empty &&
            dut.u_fifo.rd_ptr == 0 && model_count < DEPTH) cov_wrap     = cov_wrap + 1;
    end
endtask


// Helper: verify rd_data after a read (1-cycle registered delay)

task check_rd_data;
    input [DATA_WIDTH-1:0] expected;
    input [8*32-1:0] tname;
    input integer cyc;
    begin
        #1;
        if (rd_data !== expected) begin
            $display("RD_DATA MISMATCH at time %0t ns", $time);
            $display("  Test     : %s", tname);
            $display("  Cycle    : %0d", cyc);
            $display("  Expected : 0x%02h", expected);
            $display("  Got      : 0x%02h", rd_data);
            $finish;
        end
    end
endtask


//   TEST 1: Reset Test

task test_reset;
    begin
        $display("--------------------------------------------");
        $display("TEST 1: Reset Test");
        do_reset(4);

        // After reset: count==0, rd_empty==1, wr_full==0
        #1;
        if (count !== 0) begin
            $display("ERROR: Reset Test – count expected 0, got %0d", count); $finish; end
        if (rd_empty !== 1'b1) begin
            $display("ERROR: Reset Test – rd_empty expected 1, got %b", rd_empty); $finish; end
        if (wr_full !== 1'b0) begin
            $display("ERROR: Reset Test – wr_full expected 0, got %b", wr_full); $finish; end

        $display("PASS: Reset Test");
    end
endtask


//   TEST 2: Single Write / Read Test

task test_single_wr_rd;
    reg [DATA_WIDTH-1:0] wdata;
    begin
        $display("--------------------------------------------");
        $display("TEST 2: Single Write / Read Test");
        do_reset(2);
        wdata = 8'hA5;

        // Write one word
        wr_en   = 1'b1;
        wr_data = wdata;
        rd_en   = 1'b0;
        tick("Single_WR_RD");     // cycle 1: write

        if (count !== 1) begin
            $display("ERROR: count after write = %0d, expected 1", count); $finish; end

        // Stop writing
        wr_en = 1'b0;
        tick("Single_WR_RD");     // idle cycle

        // Read one word
        rd_en = 1'b1;
        tick("Single_WR_RD");     // cycle 3: read

        // Check data IMMEDIATELY after the read tick (1-cycle latency)
        rd_en = 1'b0; 
        check_rd_data(model_rd_data, "Single_WR_RD", cycle);

        if (count !== 0) begin
            $display("ERROR: count after read = %0d, expected 0", count); $finish; end

        $display("PASS: Single Write / Read Test");
    end
endtask


//   TEST 3: Fill Test (Full Condition)

task test_fill;
    integer i;
    begin
        $display("--------------------------------------------");
        $display("TEST 3: Fill Test");
        do_reset(2);

        for (i = 0; i < DEPTH; i = i + 1) begin
            wr_en   = 1'b1;
            wr_data = i[DATA_WIDTH-1:0];
            rd_en   = 1'b0;
            tick("Fill_Test");
        end
        wr_en = 1'b0;
        #1;

        if (count !== DEPTH) begin
            $display("ERROR: count after fill = %0d, expected %0d", count, DEPTH); $finish; end
        if (wr_full !== 1'b1) begin
            $display("ERROR: wr_full expected 1 after fill, got %b", wr_full); $finish; end

        $display("PASS: Fill Test");
    end
endtask


//   TEST 4: Drain Test (Empty Condition)


//   TEST 4: Drain Test (Empty Condition)

task test_drain;
    integer i;
    reg [DATA_WIDTH-1:0] expected_data;
    begin
        $display("--------------------------------------------");
        $display("TEST 4: Drain Test");
        // Fill first
        do_reset(2);
        for (i = 0; i < DEPTH; i = i + 1) begin
            wr_en   = 1'b1;
            wr_data = i[DATA_WIDTH-1:0];
            rd_en   = 1'b0;
            tick("Drain_Test_fill");
        end
        wr_en = 1'b0;

        // Drain continuously (100% throughput)
        for (i = 0; i < DEPTH; i = i + 1) begin
            rd_en = 1'b1;
            wr_en = 1'b0;
            tick("Drain_Test");

            check_rd_data(model_rd_data, "Drain_Test", cycle);
        end
        rd_en = 1'b0;
        #1;

        if (count !== 0) begin
            $display("ERROR: count after drain = %0d, expected 0", count); $finish; end
        if (rd_empty !== 1'b1) begin
            $display("ERROR: rd_empty expected 1 after drain, got %b", rd_empty); $finish; end

        $display("PASS: Drain Test");
    end
endtask

//   TEST 5: Overflow Attempt Test

task test_overflow;
    integer i;
    reg [ADDR_WIDTH:0] cnt_before;
    begin
        $display("--------------------------------------------");
        $display("TEST 5: Overflow Attempt Test");
        // Fill FIFO
        do_reset(2);
        for (i = 0; i < DEPTH; i = i + 1) begin
            wr_en   = 1'b1;
            wr_data = i[DATA_WIDTH-1:0];
            rd_en   = 1'b0;
            tick("Overflow_fill");
        end
        wr_en = 1'b0;
        #1; cnt_before = count;

        // Attempt 3 extra writes
        wr_en   = 1'b1;
        wr_data = 8'hFF;
        rd_en   = 1'b0;
        tick("Overflow_Test");
        tick("Overflow_Test");
        tick("Overflow_Test");
        wr_en = 1'b0;
        #1;

        if (count !== DEPTH) begin
            $display("ERROR: Overflow – count changed to %0d, expected %0d", count, DEPTH); $finish; end

        $display("PASS: Overflow Attempt Test");
    end
endtask


//   TEST 6: Underflow Attempt Test

task test_underflow;
    integer i;
    reg [DATA_WIDTH-1:0] rd_data_before;
    begin
        $display("--------------------------------------------");
        $display("TEST 6: Underflow Attempt Test");
        do_reset(2);
        // FIFO is empty – attempt 3 reads
        rd_en = 1'b1;
        wr_en = 1'b0;
        tick("Underflow_Test");
        tick("Underflow_Test");
        tick("Underflow_Test");
        rd_en = 1'b0;
        #1;

        if (count !== 0) begin
            $display("ERROR: Underflow – count changed to %0d, expected 0", count); $finish; end
        if (rd_empty !== 1'b1) begin
            $display("ERROR: Underflow – rd_empty expected 1, got %b", rd_empty); $finish; end

        $display("PASS: Underflow Attempt Test");
    end
endtask


//   TEST 7: Simultaneous Read / Write Test

task test_simul_rw;
    integer i;
    reg [DATA_WIDTH-1:0] wdata;
    reg [ADDR_WIDTH:0]   cnt_before;
    begin
        $display("--------------------------------------------");
        $display("TEST 7: Simultaneous Read / Write Test");
        do_reset(2);

        // Pre-fill half
        for (i = 0; i < DEPTH/2; i = i + 1) begin
            wr_en   = 1'b1;
            wr_data = i[DATA_WIDTH-1:0];
            rd_en   = 1'b0;
            tick("SimulRW_prefill");
        end
        wr_en = 1'b0;
        #1; cnt_before = count;

        // Simultaneous RW for 8 cycles
        for (i = 0; i < 8; i = i + 1) begin
            wdata   = (8'h80 + i[DATA_WIDTH-1:0]);
            wr_en   = 1'b1;
            wr_data = wdata;
            rd_en   = 1'b1;
            tick("SimulRW_Test");
        end
        #1;

        // count must be unchanged from before simultaneous phase
        if (count !== cnt_before) begin
            $display("ERROR: SimulRW – count changed from %0d to %0d", cnt_before, count); $finish; end

        wr_en = 1'b0;
        rd_en = 1'b0;
        $display("PASS: Simultaneous Read / Write Test");
    end
endtask




//   TEST 8: Pointer Wrap-Around Test

task test_wrap;
    integer i;
    reg [DATA_WIDTH-1:0] ref_data [0:DEPTH-1];
    begin
        $display("--------------------------------------------");
        $display("TEST 8: Pointer Wrap-Around Test");
        do_reset(2);

        // Fill the FIFO
        for (i = 0; i < DEPTH; i = i + 1) begin
            wr_en   = 1'b1;
            wr_data = (8'h10 + i[DATA_WIDTH-1:0]);
            rd_en   = 1'b0;
            tick("Wrap_fill");
        end
        wr_en = 1'b0;

        // Drain completely – continuous reads
        for (i = 0; i < DEPTH; i = i + 1) begin
            rd_en = 1'b1;
            wr_en = 1'b0;
            tick("Wrap_drain");

            // Verify immediately
            check_rd_data(model_rd_data, "Wrap_drain", cycle);
        end
        rd_en = 1'b0;

        // Now re-fill to force wr_ptr to wrap
        for (i = 0; i < DEPTH; i = i + 1) begin
            ref_data[i] = (8'h50 + i[DATA_WIDTH-1:0]);
            wr_en   = 1'b1;
            wr_data = ref_data[i];
            rd_en   = 1'b0;
            tick("Wrap_refill");
        end
        wr_en = 1'b0;

        // Drain again continuously
        for (i = 0; i < DEPTH; i = i + 1) begin
            rd_en = 1'b1;
            wr_en = 1'b0;
            tick("Wrap_redrain");

            // Verify immediately
            check_rd_data(model_rd_data, "Wrap_redrain", cycle);
        end
        rd_en = 1'b0;

        $display("PASS: Pointer Wrap-Around Test");
    end
    
endtask

// Main simulation body
//   TEST 9: Random Test

task test_random;
    integer i;
    begin
        $display("--------------------------------------------");
        $display("TEST 9: Random Test (seed=%0d)", seed);

        do_reset(2);

        for (i = 0; i < 200; i = i + 1) begin
            // Randomize inputs using seed
            wr_en   = $random(seed) % 2;
            rd_en   = $random(seed) % 2;
            wr_data = $random(seed) % (1 << DATA_WIDTH);

            tick("Random_Test");
        end

        // Stop activity
        wr_en = 0;
        rd_en = 0;

        $display("PASS: Random Test");
    end
endtask

initial begin
    // Init
    seed         = 12345;
    cycle        = 0;
    global_cycle = 0;
    cov_full      = 0;
    cov_empty     = 0;
    cov_wrap      = 0;
    cov_simul     = 0;
    cov_overflow  = 0;
    cov_underflow = 0;

    wr_en   = 0;
    rd_en   = 0;
    wr_data = 0;
    rst_n   = 0;

    $display("  Synchronous FIFO Testbench Starting");
    $display("  DATA_WIDTH=%0d  DEPTH=%0d", DATA_WIDTH, DEPTH);

    // ---- Run all directed tests ----
    test_reset;
    test_single_wr_rd;
    test_fill;
    test_drain;
    test_overflow;
    test_underflow;
    test_simul_rw;
    test_wrap;
    test_random;

    // ---- Coverage Summary ----
    $display("  COVERAGE SUMMARY");
    $display("  cov_full      = %0d", cov_full);
    $display("  cov_empty     = %0d", cov_empty);
    $display("  cov_wrap      = %0d", cov_wrap);
    $display("  cov_simul     = %0d", cov_simul);
    $display("  cov_overflow  = %0d", cov_overflow);
    $display("  cov_underflow = %0d", cov_underflow);

    // Check all counters non-zero
    if (cov_full == 0 || cov_empty == 0 || cov_wrap == 0 ||
        cov_simul == 0 || cov_overflow == 0 || cov_underflow == 0) begin
        $display("WARNING: One or more coverage counters are zero!");
        $display("         Coverage may be incomplete.");
    end else begin
        $display("  All coverage counters non-zero – GOOD coverage.");
    end

    $display("============================================");
    $display("  ALL TESTS PASSED. Total cycles: %0d", global_cycle);
    $finish;
end


// Timeout watchdog (prevent infinite loops)

initial begin
    #(CLK_PERIOD * 100000);
    $display("ERROR: Simulation timeout!");
    $finish;
end


// Optional: VCD dump for waveform inspection

initial begin
    $dumpfile("fifo_sim.vcd");
    $dumpvars(0, tb_sync_fifo);
end

endmodule
