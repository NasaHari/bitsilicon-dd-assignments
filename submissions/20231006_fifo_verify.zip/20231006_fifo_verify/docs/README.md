# Synchronous FIFO – Assignment 2

## Overview

This submission implements a **synchronous FIFO** (First-In First-Out) queue in Verilog, along with a fully self-checking testbench that uses a golden reference model and an automatic scoreboard.

---

## Directory Structure

```
20231006_fifo_verify/
├── rtl/
│   ├── sync_fifo_top.v    ← Top-level module 
│   └── sync_fifo.v        ← Core FIFO implementation
├── tb/
│   └── tb_sync_fifo.v     ← Self-checking testbench
└── docs/
    └── README.md          ← This file
```

---

## RTL Design – `sync_fifo.v` / `sync_fifo_top.v`

### Parameters

| Parameter    | Default | Description                        |
|--------------|---------|------------------------------------|
| `DATA_WIDTH` | 8       | Width of each data word (bits)     |
| `DEPTH`      | 16      | Number of entries in the FIFO      |

`ADDR_WIDTH` is computed internally via a `clog2()` function: `ADDR_WIDTH = clog2(DEPTH)`.

### Interface

| Port       | Direction | Width              | Description                     |
|------------|-----------|--------------------|---------------------------------|
| `clk`      | input     | 1                  | Clock (rising-edge active)      |
| `rst_n`    | input     | 1                  | Synchronous, active-low reset   |
| `wr_en`    | input     | 1                  | Write enable                    |
| `wr_data`  | input     | DATA_WIDTH         | Write data                      |
| `wr_full`  | output    | 1                  | FIFO full flag                  |
| `rd_en`    | input     | 1                  | Read enable                     |
| `rd_data`  | output    | DATA_WIDTH         | Registered read data            |
| `rd_empty` | output    | 1                  | FIFO empty flag                 |
| `count`    | output    | ADDR_WIDTH+1       | Number of valid entries stored  |

### Design Decisions

- **Synchronous reset** – All state is reset on the rising clock edge when `rst_n` is low.
- **Registered read data** – `rd_data` is a `reg`, updated one cycle after `rd_en` assertion.
- **Pointer wrap** – Both `wr_ptr` and `rd_ptr` wrap to 0 when they reach `DEPTH-1`.
- **Count logic**  
  - Write only → `count++`  
  - Read only → `count--`  
  - Simultaneous valid read + write → `count` unchanged  
  - Neither → `count` unchanged  
- **Overflow / Underflow protection** – Writes ignored when `wr_full`; reads ignored when `rd_empty`.

---

## Testbench – `tb_sync_fifo.v`

### Golden Reference Model

An independent behavioral model maintains:
- `model_mem[]` – separate storage array
- `model_wr_ptr`, `model_rd_ptr`, `model_count` – own state variables
- `model_rd_data` – expected read data

Updates happen on the same `posedge clk` as the DUT, using the model's own state (never DUT outputs).

### Scoreboard

After every clock edge, the scoreboard automatically compares:
- `DUT.count` vs `model_count`
- `DUT.rd_empty` vs `(model_count  0)`
- `DUT.wr_full` vs `(model_count  DEPTH)`
- `DUT.rd_data` vs `model_rd_data` (where applicable)

On any mismatch, a detailed error is printed (time, cycle, test name, seed, expected, actual, input signals, model pointer values) and simulation terminates immediately via `$finish`.

### Directed Tests

| # | Test Name                    | Purpose                                             |
|---|------------------------------|-----------------------------------------------------|
| 1 | Reset Test                   | Verifies all state zeroes after reset               |
| 2 | Single Write / Read Test     | Basic data integrity: write one word, read it back  |
| 3 | Fill Test                    | Verifies full flag and overflow prevention          |
| 4 | Drain Test                   | Verifies empty flag and FIFO ordering               |
| 5 | Overflow Attempt Test        | Extra writes when full must not corrupt state       |
| 6 | Underflow Attempt Test       | Extra reads when empty must not corrupt state       |
| 7 | Simultaneous Read/Write Test | Count unchanged, both pointers advance              |
| 8 | Pointer Wrap-Around Test     | Data integrity across pointer boundary crossings    |

### Coverage Counters

| Counter        | Meaning                                      |
|----------------|----------------------------------------------|
| `cov_full`     | Cycles where FIFO was at full capacity       |
| `cov_empty`    | Cycles where FIFO was empty                  |
| `cov_wrap`     | Pointer wrap-around events                   |
| `cov_simul`    | Valid simultaneous read+write cycles         |
| `cov_overflow` | Write attempts when FIFO was full            |
| `cov_underflow`| Read attempts when FIFO was empty            |

All counters are printed at end-of-simulation. A warning is issued if any counter is zero.

---

## How to Simulate (Icarus Verilog)

```bash
# Compile
iverilog -o fifo_sim \
    rtl/sync_fifo_top.v \
    rtl/sync_fifo.v \
    tb/tb_sync_fifo.v

# Run
vvp fifo_sim

# View waveforms (optional)
gtkwave fifo_sim.vcd
```

### Expected Output (passing)

```

  Synchronous FIFO Testbench Starting
  DATA_WIDTH=8  DEPTH=16

--------------------------------------------
TEST 1: Reset Test
PASS: Reset Test
...
--------------------------------------------
TEST 8: Pointer Wrap-Around Test
PASS: Pointer Wrap-Around Test

  COVERAGE SUMMARY
  cov_full      = ...
  cov_empty     = ...
  cov_wrap      = ...
  cov_simul     = ...
  cov_overflow  = ...
  cov_underflow = ...

  All coverage counters non-zero – GOOD coverage.

  ALL TESTS PASSED. Total cycles: ...

```

---


